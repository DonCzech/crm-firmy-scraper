"use client";

import { useEffect, useState } from "react";
import { Plus, ChevronDown, ChevronRight, Trash2, ArrowUp, ArrowDown, RotateCcw } from "lucide-react";
import type { Section } from "@/lib/db";
import type { StudioState } from "../TenantStudioView";

type SectionWithMeta = Section & {
  _modifiedPaths?: string[];
  _resolvedSource?: "legacy" | "template";
  content_source?: string | null;
};

// Preferred array field name per section type — used when the key actually exists in content.
// Multiple candidates can be listed (first match wins).
const ARRAY_KEYS: Record<string, { keys: string[]; itemLabel: string }> = {
  services:     { keys: ["services", "items", "cards"],                   itemLabel: "name" },
  pricing:      { keys: ["plans", "packages", "items", "services"],       itemLabel: "name" },
  testimonials: { keys: ["testimonials", "reviews", "items"],             itemLabel: "name" },
  gallery:      { keys: ["images"],                                       itemLabel: "alt" },
  faq:          { keys: ["faq", "items", "faqs"],                         itemLabel: "question" },
  team:         { keys: ["members", "team", "items"],                     itemLabel: "name" },
};

// Variant-specific overrides — checked before section_type lookup
const ARRAY_KEYS_BY_VARIANT: Record<string, { keys: string[]; itemLabel: string }> = {
  "reality-03-navbar":         { keys: ["links"],   itemLabel: "label" },
  "hero-reality-03-video":     { keys: ["stats"],   itemLabel: "number" },
  "reality-03-services-4grid": { keys: ["items"],   itemLabel: "name" },
  "reality-03-listings":       { keys: ["items"],   itemLabel: "title" },
  "reality-03-testimonials":   { keys: ["items"],   itemLabel: "author" },
  "reality-03-blog":           { keys: ["items"],   itemLabel: "title" },
  "reality-03-footer":         { keys: ["agents"],  itemLabel: "name" },
};

// Auto-detect the first array-of-objects field in content (skip internal + gallery images).
function autoDetectArrayField(
  content: Record<string, unknown>,
  sectionType: string
): { key: string; itemLabel: string } | null {
  // Skip gallery's images array — handled by GalleryInspectorPanel
  const skipKeys = new Set(sectionType === "gallery" ? ["images"] : []);

  for (const [k, v] of Object.entries(content)) {
    if (k.startsWith("__") || skipKeys.has(k)) continue;
    if (Array.isArray(v) && v.length > 0 && typeof v[0] === "object" && v[0] !== null && !Array.isArray(v[0])) {
      const first = v[0] as Record<string, unknown>;
      // Pick a human-readable label key
      const labelKey = (["name", "title", "question", "label", "text", "author"] as const)
        .find((lk) => typeof first[lk] === "string") ?? Object.keys(first)[0] ?? "0";
      return { key: k, itemLabel: labelKey };
    }
  }
  return null;
}

// Resolve the actual array definition: try registry first (matching key in content), then auto-detect.
function resolveArrayDef(
  content: Record<string, unknown>,
  sectionType: string,
  sectionVariant: string
): { key: string; itemLabel: string } | null {
  const registered = ARRAY_KEYS_BY_VARIANT[sectionVariant] ?? ARRAY_KEYS[sectionType];
  if (registered) {
    // Try each candidate key and return the first that actually exists in content
    const match = registered.keys.find((k) => Array.isArray(content[k]) && (content[k] as unknown[]).length >= 0);
    if (match) return { key: match, itemLabel: registered.itemLabel };
  }
  // Fall back to auto-detection for any section type
  return autoDetectArrayField(content, sectionType);
}

const ITEM_FIELDS: Record<string, Array<{ key: string; label: string; type: "text" | "textarea" | "url" | "number" }>> = {
  services: [
    { key: "name", label: "Název", type: "text" },
    { key: "description", label: "Popis", type: "textarea" },
    { key: "price", label: "Cena", type: "text" },
    { key: "duration", label: "Doba", type: "text" },
  ],
  pricing: [
    { key: "name", label: "Název", type: "text" },
    { key: "description", label: "Popis", type: "textarea" },
    { key: "price", label: "Cena", type: "text" },
    { key: "duration", label: "Doba", type: "text" },
  ],
  testimonials: [
    { key: "name", label: "Jméno", type: "text" },
    { key: "text", label: "Text", type: "textarea" },
    { key: "rating", label: "Hodnocení", type: "number" },
  ],
  gallery: [
    { key: "url", label: "URL", type: "url" },
    { key: "alt", label: "Popis", type: "text" },
  ],
  faq: [
    { key: "question", label: "Otázka", type: "text" },
    { key: "answer", label: "Odpověď", type: "textarea" },
  ],
  team: [
    { key: "name", label: "Jméno", type: "text" },
    { key: "role", label: "Pozice", type: "text" },
    { key: "bio", label: "Bio", type: "textarea" },
    { key: "image", label: "Foto URL", type: "url" },
  ],
  // reality-03 variant fields
  "reality-03-navbar": [
    { key: "label", label: "Název odkazu", type: "text" },
    { key: "href",  label: "Odkaz",        type: "url" },
  ],
  "hero-reality-03-video": [
    { key: "number", label: "Číslo",  type: "text" },
    { key: "label",  label: "Popis",  type: "text" },
  ],
  "reality-03-services-4grid": [
    { key: "name",    label: "Záložka",     type: "text" },
    { key: "title",   label: "Nadpis",      type: "text" },
    { key: "body",    label: "Text",        type: "textarea" },
    { key: "ctaText", label: "CTA – text",  type: "text" },
    { key: "ctaHref", label: "CTA – odkaz", type: "url" },
  ],
  "reality-03-listings": [
    { key: "title",    label: "Název",        type: "text" },
    { key: "location", label: "Lokalita",     type: "text" },
    { key: "price",    label: "Cena",         type: "text" },
    { key: "type",     label: "Typ (prodej/pronajem)", type: "text" },
    { key: "image",    label: "Foto URL",     type: "url" },
  ],
  "reality-03-testimonials": [
    { key: "text",   label: "Text recenze", type: "textarea" },
    { key: "author", label: "Autor",        type: "text" },
    { key: "rating", label: "Hodnocení",    type: "number" },
  ],
  "reality-03-blog": [
    { key: "title", label: "Nadpis článku", type: "text" },
    { key: "href",  label: "Odkaz",         type: "url" },
    { key: "image", label: "Foto URL",      type: "url" },
  ],
  "reality-03-footer": [
    { key: "name",  label: "Jméno",     type: "text" },
    { key: "role",  label: "Pozice",    type: "text" },
    { key: "phone", label: "Telefon",   type: "text" },
    { key: "email", label: "E-mail",    type: "text" },
    { key: "image", label: "Foto URL",  type: "url" },
  ],
};

const SCALAR_LABELS: Record<string, string> = {
  title: "Nadpis",
  subtitle: "Podnadpis",
  tagline: "Tagline",
  description: "Popis",
  body: "Text",
  text: "Text",
  ctaLabel: "Tlačítko – text",
  ctaText: "CTA – text",
  ctaHref: "CTA – odkaz",
  ctaSecondaryText: "CTA 2 – text",
  ctaSecondaryHref: "CTA 2 – odkaz",
  buttonLabel: "Tlačítko – text",
  buttonHref: "Tlačítko – odkaz",
  image: "Obrázek URL",
  imageUrl: "Obrázek URL",
  backgroundImage: "Pozadí URL",
  agentImage: "Foto makléře URL",
  agentName: "Jméno makléře",
  titleAccent: "Nadpis – akcent",
  siteName: "Název webu",
  logoUrl: "Logo URL",
  phone: "Telefon",
  email: "E-mail",
  address: "Adresa",
  ico: "IČO",
  hours: "Otevírací doba",
  facebookUrl: "Facebook URL",
  instagramUrl: "Instagram URL",
  linkedinUrl: "LinkedIn URL",
};

// Fields that are internal/structural and should not be shown in the inspector
const HIDDEN_SCALAR_KEYS = new Set(["id", "logoUrl"]);

export function ContentInspectorTab({ section, state }: { section: Section; state: StudioState }) {
  const sec = section as SectionWithMeta;
  const content = (section.settings?.content ?? {}) as Record<string, unknown>;
  const arrayDef = resolveArrayDef(content, section.section_type, section.section_variant);
  const scalarEntries = Object.entries(content).filter(([k, v]) => (
    !k.startsWith("__") &&
    !HIDDEN_SCALAR_KEYS.has(k) &&
    (typeof v === "string" || typeof v === "number") &&
    (!arrayDef || k !== arrayDef.key)
  )) as Array<[string, string | number]>;
  const modifiedPaths = new Set(sec._modifiedPaths ?? []);
  const isV2 = sec.content_source === "v2";
  const hasOverrides = modifiedPaths.size > 0;

  function update(key: string, value: unknown) {
    const nextContent = { ...content, [key]: value };
    void state.patchSection(section.id, {
      settings: { ...(section.settings ?? {}), content: nextContent },
    });
  }

  async function resetSection() {
    if (!isV2) return;
    if (!confirm("Vrátit celou sekci na výchozí stav šablony? Tato akce zruší vaše úpravy v této sekci.")) return;
    try {
      const res = await fetch(`/api/demo/${state.tenant.slug}/sections/${section.id}/reset-overrides`, { method: "POST" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      window.location.reload();
    } catch (err) {
      alert("Reset selhal: " + (err instanceof Error ? err.message : "unknown"));
    }
  }

  return (
    <div className="space-y-4 p-3">
      {isV2 && hasOverrides && (
        <div className="flex items-center justify-between gap-2 rounded-md border border-[var(--vs-accent-ring)] bg-[var(--vs-accent-bg)] px-2.5 py-1.5">
          <span className="text-[10.5px] text-[var(--vs-accent-hi)]">
            {modifiedPaths.size} {modifiedPaths.size === 1 ? "úprava" : modifiedPaths.size < 5 ? "úpravy" : "úprav"} vs šablona
          </span>
          <button
            type="button"
            onClick={resetSection}
            className="inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[10.5px] text-[var(--vs-accent-hi)] hover:bg-[var(--vs-accent-bg)]"
            title="Vrátit sekci na výchozí stav šablony"
          >
            <RotateCcw className="h-3 w-3" strokeWidth={2} />
            Reset
          </button>
        </div>
      )}

      {scalarEntries.length === 0 && !arrayDef && (
        <p className="px-1 text-[11px] text-[var(--vs-text-muted)]">
          Tento typ sekce upravuj klikáním přímo v náhledu.
        </p>
      )}

      {scalarEntries.map(([key, value]) => (
        <Field
          key={key}
          label={SCALAR_LABELS[key] ?? key}
          value={String(value ?? "")}
          multiline={typeof value === "string" && value.length > 60}
          onChange={(v) => update(key, v)}
          isModified={modifiedPaths.has(key)}
        />
      ))}

      {arrayDef && (
        <ArraySection
          section={section}
          state={state}
          arrayKey={arrayDef.key}
          itemLabelKey={arrayDef.itemLabel}
        />
      )}
    </div>
  );
}

function Field({
  label, value, onChange, multiline, isModified,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  multiline?: boolean;
  isModified?: boolean;
}) {
  const [local, setLocal] = useState(value);
  useEffect(() => { setLocal(value); }, [value]);
  return (
    <label className="block">
      <span className="mb-1 flex items-center gap-1.5 text-[10.5px] font-medium uppercase tracking-wide text-[var(--vs-text-muted)]">
        {label}
        {isModified && (
          <span
            className="inline-block h-1.5 w-1.5 rounded-full bg-blue-400"
            title="Změněno oproti výchozí šabloně"
          />
        )}
      </span>
      {multiline ? (
        <textarea
          value={local}
          onChange={(e) => setLocal(e.target.value)}
          onBlur={() => local !== value && onChange(local)}
          rows={3}
          className="w-full resize-none rounded-md border border-[var(--vs-border)] bg-[var(--vs-bg-soft)] px-2.5 py-2 text-xs text-[var(--vs-text)] placeholder-[var(--vs-text-dim)] outline-none transition-colors focus:border-[var(--vs-accent)]"
        />
      ) : (
        <input
          type="text"
          value={local}
          onChange={(e) => setLocal(e.target.value)}
          onBlur={() => local !== value && onChange(local)}
          className="h-8 w-full rounded-md border border-[var(--vs-border)] bg-[var(--vs-bg-soft)] px-2.5 text-xs text-[var(--vs-text)] placeholder-[var(--vs-text-dim)] outline-none transition-colors focus:border-[var(--vs-accent)]"
        />
      )}
    </label>
  );
}

function inferItemFields(
  item: Record<string, unknown>
): Array<{ key: string; label: string; type: "text" | "textarea" | "url" | "number" }> {
  return Object.keys(item)
    .filter((k) => !k.startsWith("__") && typeof item[k] !== "object")
    .map((k) => ({
      key: k,
      label: SCALAR_LABELS[k] ?? k,
      type: (
        k.includes("Href") || k.includes("href") || k.includes("Url") || k.includes("url") || k.includes("link") || k.includes("Link")
          ? "url"
          : k === "description" || k === "text" || k === "body" || k === "bio" || k === "answer" || k === "quote"
          ? "textarea"
          : typeof item[k] === "number"
          ? "number"
          : "text"
      ) as "text" | "textarea" | "url" | "number",
    }));
}

function ArraySection({
  section, state, arrayKey, itemLabelKey,
}: {
  section: Section;
  state: StudioState;
  arrayKey: string;
  itemLabelKey: string;
}) {
  const content = (section.settings?.content ?? {}) as Record<string, unknown>;
  const items = (content[arrayKey] ?? []) as Record<string, unknown>[];
  // Use registered fields, or auto-infer from first item
  const registeredFields = ITEM_FIELDS[section.section_variant] ?? ITEM_FIELDS[section.section_type];
  const fields = registeredFields ?? (items[0] ? inferItemFields(items[0]) : []);
  const [expanded, setExpanded] = useState<number | null>(null);

  function commit(next: Record<string, unknown>[]) {
    const nextContent = { ...content, [arrayKey]: next };
    void state.patchSection(section.id, {
      settings: { ...(section.settings ?? {}), content: nextContent },
    });
  }

  return (
    <div>
      <div className="mb-2 flex items-center justify-between">
        <span className="text-[10.5px] font-medium uppercase tracking-wide text-[var(--vs-text-muted)]">Položky</span>
        <span className="text-[10.5px] text-[var(--vs-text-dim)]">{items.length}</span>
      </div>
      <div className="space-y-1.5">
        {items.map((item, i) => {
          const open = expanded === i;
          const label = String(item[itemLabelKey] ?? `Položka ${i + 1}`);
          return (
            <div key={i} className="overflow-hidden rounded-md border border-[var(--vs-border)] bg-[var(--vs-bg-soft)]">
              <button
                type="button"
                onClick={() => setExpanded(open ? null : i)}
                className="flex w-full items-center gap-1.5 px-2 py-1.5 text-left text-xs text-[var(--vs-text)] hover:bg-[var(--vs-surface)]"
              >
                {open ? <ChevronDown className="h-3.5 w-3.5 text-[var(--vs-text-muted)]" strokeWidth={1.75} /> : <ChevronRight className="h-3.5 w-3.5 text-[var(--vs-text-muted)]" strokeWidth={1.75} />}
                <span className="flex-1 truncate">{label}</span>
              </button>
              {open && (
                <div className="space-y-2 border-t border-[var(--vs-border)] p-2">
                  {fields.map((f) => (
                    <Field
                      key={f.key}
                      label={f.label}
                      value={String(item[f.key] ?? "")}
                      multiline={f.type === "textarea"}
                      onChange={(v) => {
                        const next = items.map((it, idx) => idx === i ? { ...it, [f.key]: f.type === "number" ? Number(v) : v } : it);
                        commit(next);
                      }}
                    />
                  ))}
                  <div className="flex items-center justify-end gap-1 border-t border-[var(--vs-border)] pt-2">
                    <ItemBtn
                      label="Nahoru"
                      disabled={i === 0}
                      onClick={() => {
                        const next = [...items];
                        [next[i - 1], next[i]] = [next[i], next[i - 1]];
                        commit(next);
                        setExpanded(i - 1);
                      }}
                    >
                      <ArrowUp className="h-3.5 w-3.5" strokeWidth={1.75} />
                    </ItemBtn>
                    <ItemBtn
                      label="Dolů"
                      disabled={i === items.length - 1}
                      onClick={() => {
                        const next = [...items];
                        [next[i], next[i + 1]] = [next[i + 1], next[i]];
                        commit(next);
                        setExpanded(i + 1);
                      }}
                    >
                      <ArrowDown className="h-3.5 w-3.5" strokeWidth={1.75} />
                    </ItemBtn>
                    <ItemBtn
                      label="Smazat"
                      danger
                      onClick={() => {
                        commit(items.filter((_, idx) => idx !== i));
                        setExpanded(null);
                      }}
                    >
                      <Trash2 className="h-3.5 w-3.5" strokeWidth={1.75} />
                    </ItemBtn>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
      <button
        type="button"
        onClick={() => {
          // Clone last item (preserves structure) or create blank from fields
          const template = items.length > 0
            ? Object.fromEntries(Object.entries(items[items.length - 1]).map(([k, v]) => [k, typeof v === "number" ? v : ""]))
            : Object.fromEntries(fields.map(f => [f.key, f.type === "number" ? 5 : ""]));
          commit([...items, template]);
          setExpanded(items.length);
        }}
        className="mt-2 flex w-full items-center justify-center gap-1.5 rounded-md border border-dashed border-[var(--vs-border-strong)] py-2 text-xs text-[var(--vs-text-muted)] hover:border-[var(--vs-accent-ring)] hover:text-[var(--vs-text)]"
      >
        <Plus className="h-3.5 w-3.5" strokeWidth={1.75} /> Přidat položku
      </button>
    </div>
  );
}

function ItemBtn({ children, label, onClick, disabled, danger }: { children: React.ReactNode; label: string; onClick: () => void; disabled?: boolean; danger?: boolean }) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      disabled={disabled}
      className={`inline-flex h-6 w-6 items-center justify-center rounded text-[var(--vs-text-muted)] hover:bg-[var(--vs-surface-3)] ${danger ? "hover:text-[var(--vs-danger)]" : "hover:text-[var(--vs-text)]"} disabled:opacity-30 disabled:hover:bg-transparent`}
    >
      {children}
    </button>
  );
}
