"use client";

/**
 * Dark-themed "+ Přidat" button — sits in StudioShell's SecondaryActionBar.
 * Visual language matches the rest of the dark editor chrome (vs-* tokens,
 * indigo accent on active). Wix puts an identical button as the primary
 * action on the secondary toolbar; we mirror that placement while keeping
 * our own brand surface so it doesn't look like a transplant.
 */

import { Plus } from "lucide-react";
import clsx from "clsx";
import { toggleWixAdd, useWixAdd } from "./wix-add-state";

export function WixAddButton() {
  const view = useWixAdd();
  const active = view !== "closed";
  return (
    <button
      type="button"
      onClick={toggleWixAdd}
      aria-label="Přidat"
      data-tour-id="wix-add-button"
      aria-expanded={active}
      className={clsx(
        "flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[13px] font-semibold transition-[background,color,box-shadow] duration-100",
        active
          ? "bg-[rgba(59,130,246,0.16)] text-[#93c5fd] shadow-[inset_0_0_0_1px_rgba(59,130,246,0.35)]"
          : "bg-[#3b82f6] text-white hover:bg-[#2563eb] shadow-[0_2px_8px_rgba(59,130,246,0.3)]",
      )}
    >
      <Plus size={14} strokeWidth={2.5} />
      <span>Přidat</span>
    </button>
  );
}
